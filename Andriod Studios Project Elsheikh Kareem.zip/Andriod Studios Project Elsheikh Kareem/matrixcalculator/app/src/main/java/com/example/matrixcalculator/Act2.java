package com.example.matrixcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Act2 extends AppCompatActivity
{
    static TextView[] e = new TextView[16];

@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        Intent i = getIntent();

        int[] result = i.getIntArrayExtra("Extra");
        int j;
        String[] g = new String[16];

        for (j = 0; j < 16; j++)
        {
            String s = "n" + j;
            e[j] = findViewById(getResources().getIdentifier(s, "id", getPackageName()));
        }
        e[15] = findViewById(R.id.n15);
        String x = i.getStringExtra("which");
        e[15].setText(x);

        for(j=0;j<16;j++)
        {
            g[j] = Integer.toString(result[j]);
        }
        for (j = 0; j<16;j++)
        {
            e[j].setText(g[j]);
        }
    }
    public void Return(View view)
    {

        Intent i2 = new Intent(this, MainActivity.class);

        startActivity(i2);
    }
}
