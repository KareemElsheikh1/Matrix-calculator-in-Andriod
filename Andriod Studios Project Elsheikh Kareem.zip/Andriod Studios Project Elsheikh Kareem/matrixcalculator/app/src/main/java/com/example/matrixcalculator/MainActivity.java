package com.example.matrixcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    static Map<Integer, String> Values = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int j = 0; j < 32; j++) {
            Values.put(j, "0");
        }

        setContentView(R.layout.activity_main);
        EditText mytextbox0 = (EditText) findViewById(R.id.n0);
        mytextbox0.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(0)) {
                    Values.replace(0, s.toString());
                } else {
                    Values.put(0, s.toString());
                }
            }
        });
        EditText mytextbox1 = (EditText) findViewById(R.id.n1);
        mytextbox1.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(1)) {
                    Values.replace(1, s.toString());
                } else {
                    Values.put(1, s.toString());
                }
            }
        });
        EditText mytextbox2 = (EditText) findViewById(R.id.n2);
        mytextbox2.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(2)) {
                    Values.replace(2, s.toString());
                } else {
                    Values.put(2, s.toString());
                }
            }
        });
        EditText mytextbox3 = (EditText) findViewById(R.id.n3);
        mytextbox3.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(3)) {
                    Values.replace(3, s.toString());
                } else {
                    Values.put(3, s.toString());
                }
            }
        });
        EditText mytextbox4 = (EditText) findViewById(R.id.n4);
        mytextbox4.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(4)) {
                    Values.replace(4, s.toString());
                } else {
                    Values.put(4, s.toString());
                }
            }
        });
        EditText mytextbox5 = (EditText) findViewById(R.id.n5);
        mytextbox5.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(5)) {
                    Values.replace(5, s.toString());
                } else {
                    Values.put(5, s.toString());
                }
            }
        });
        EditText mytextbox6 = (EditText) findViewById(R.id.n6);
        mytextbox6.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(6)) {
                    Values.replace(6, s.toString());
                } else {
                    Values.put(6, s.toString());
                }
            }
        });
        EditText mytextbox7 = (EditText) findViewById(R.id.n7);
        mytextbox7.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(7)) {
                    Values.replace(7, s.toString());
                } else {
                    Values.put(7, s.toString());
                }
            }
        });
        EditText mytextbox8 = (EditText) findViewById(R.id.n8);
        mytextbox8.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(8)) {
                    Values.replace(8, s.toString());
                } else {
                    Values.put(8, s.toString());
                }
            }
        });
        EditText mytextbox9 = (EditText) findViewById(R.id.n9);
        mytextbox9.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(9)) {
                    Values.replace(9, s.toString());
                } else {
                    Values.put(9, s.toString());
                }
            }
        });
        EditText mytextbox10 = (EditText) findViewById(R.id.n10);
        mytextbox10.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(10)) {
                    Values.replace(10, s.toString());
                } else {
                    Values.put(10, s.toString());
                }
            }
        });
        EditText mytextbox11 = (EditText) findViewById(R.id.n11);
        mytextbox11.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(11)) {
                    Values.replace(11, s.toString());
                } else {
                    Values.put(11, s.toString());
                }
            }
        });
        EditText mytextbox12 = (EditText) findViewById(R.id.n12);
        mytextbox12.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(12)) {
                    Values.replace(12, s.toString());
                } else {
                    Values.put(12, s.toString());
                }
            }
        });
        EditText mytextbox13 = (EditText) findViewById(R.id.n13);
        mytextbox13.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(13)) {
                    Values.replace(13, s.toString());
                } else {
                    Values.put(13, s.toString());
                }
            }
        });
        EditText mytextbox14 = (EditText) findViewById(R.id.n14);
        mytextbox14.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(14)) {
                    Values.replace(14, s.toString());
                } else {
                    Values.put(14, s.toString());
                }
            }
        });
        EditText mytextbox15 = (EditText) findViewById(R.id.n15);
        mytextbox15.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(15)) {
                    Values.replace(15, s.toString());
                } else {
                    Values.put(15, s.toString());
                }
            }
        });
        EditText mytextbox16 = (EditText) findViewById(R.id.n16);
        mytextbox16.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(16)) {
                    Values.replace(16, s.toString());
                } else {
                    Values.put(16, s.toString());
                }
            }
        });
        EditText mytextbox17 = (EditText) findViewById(R.id.n17);
        mytextbox17.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(17)) {
                    Values.replace(17, s.toString());
                } else {
                    Values.put(17, s.toString());
                }
            }
        });
        EditText mytextbox18 = (EditText) findViewById(R.id.n18);
        mytextbox18.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(18)) {
                    Values.replace(18, s.toString());
                } else {
                    Values.put(18, s.toString());
                }
            }
        });
        EditText mytextbox19 = (EditText) findViewById(R.id.n19);
        mytextbox19.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(19)) {
                    Values.replace(19, s.toString());
                } else {
                    Values.put(19, s.toString());
                }
            }
        });
        EditText mytextbox20 = (EditText) findViewById(R.id.n20);
        mytextbox20.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(20)) {
                    Values.replace(20, s.toString());
                } else {
                    Values.put(20, s.toString());
                }
            }
        });
        EditText mytextbox21 = (EditText) findViewById(R.id.n21);
        mytextbox21.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(21)) {
                    Values.replace(21, s.toString());
                } else {
                    Values.put(21, s.toString());
                }
            }
        });
        EditText mytextbox22 = (EditText) findViewById(R.id.n22);
        mytextbox22.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(22)) {
                    Values.replace(22, s.toString());
                } else {
                    Values.put(22, s.toString());
                }
            }
        });
        EditText mytextbox23 = (EditText) findViewById(R.id.n23);
        mytextbox23.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(23)) {
                    Values.replace(23, s.toString());
                } else {
                    Values.put(23, s.toString());
                }
            }
        });
        EditText mytextbox24 = (EditText) findViewById(R.id.n24);
        mytextbox24.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(24)) {
                    Values.replace(24, s.toString());
                } else {
                    Values.put(24, s.toString());
                }
            }
        });
        EditText mytextbox25 = (EditText) findViewById(R.id.n25);
        mytextbox25.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(25)) {
                    Values.replace(25, s.toString());
                } else {
                    Values.put(25, s.toString());
                }
            }
        });
        EditText mytextbox26 = (EditText) findViewById(R.id.n26);
        mytextbox26.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(26)) {
                    Values.replace(26, s.toString());
                } else {
                    Values.put(26, s.toString());
                }
            }
        });
        EditText mytextbox27 = (EditText) findViewById(R.id.n27);
        mytextbox27.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(27)) {
                    Values.replace(27, s.toString());
                } else {
                    Values.put(27, s.toString());
                }
            }
        });
        EditText mytextbox28 = (EditText) findViewById(R.id.n28);
        mytextbox28.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(28)) {
                    Values.replace(28, s.toString());
                } else {
                    Values.put(28, s.toString());
                }
            }
        });
        EditText mytextbox29 = (EditText) findViewById(R.id.n29);
        mytextbox29.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(29)) {
                    Values.replace(29, s.toString());
                } else {
                    Values.put(29, s.toString());
                }
            }
        });
        EditText mytextbox30 = (EditText) findViewById(R.id.n30);
        mytextbox30.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(30)) {
                    Values.replace(30, s.toString());
                } else {
                    Values.put(30, s.toString());
                }
            }
        });
        EditText mytextbox31 = (EditText) findViewById(R.id.n31);
        mytextbox31.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                if (Values.containsKey(31)) {
                    Values.replace(31, s.toString());
                } else {
                    Values.put(31, s.toString());
                }
            }
        });

    }

    public void Addition(View view) {

        setContentView(R.layout.activity_main);

        int[] result = new int[16];
        int j;

        for (j = 0; j < 16; j++) {

            result[j] = Integer.parseInt(Values.get(j)) + Integer.parseInt(Values.get(j + 16));

        }
        Intent i1 = new Intent(this, Act2.class);
        i1.putExtra("Extra", result);
        String x = "Addition";
        i1.putExtra("which", x);
        startActivity(i1);
    }

    public void Subtract(View view) {

        setContentView(R.layout.activity_main);

        int[] result = new int[16];

        int j;

        for (j = 0; j < 16; j++) {

            result[j] = Integer.parseInt(Values.get(j)) - Integer.parseInt(Values.get(j + 16));

        }
        Intent i1 = new Intent(this, Act2.class);
        i1.putExtra("Extra", result);
        String x = "Subtraction";
        i1.putExtra("which", x);
        startActivity(i1);
    }

    public void Transpose(View view) {
        setContentView(R.layout.activity_main);

        int[] result = new int[16];

        int j;
        result[0] = Integer.parseInt(Values.get(0));
        result[1] = Integer.parseInt(Values.get(4));
        result[2] = Integer.parseInt(Values.get(8));
        result[3] = Integer.parseInt(Values.get(12));
        result[4] = Integer.parseInt(Values.get(1));
        result[5] = Integer.parseInt(Values.get(5));
        result[6] = Integer.parseInt(Values.get(9));
        result[7] = Integer.parseInt(Values.get(13));
        result[8] = Integer.parseInt(Values.get(2));
        result[9] = Integer.parseInt(Values.get(6));
        result[10] = Integer.parseInt(Values.get(10));
        result[11] = Integer.parseInt(Values.get(14));
        result[12] = Integer.parseInt(Values.get(3));
        result[13] = Integer.parseInt(Values.get(7));
        result[14] = Integer.parseInt(Values.get(11));
        result[15] = Integer.parseInt(Values.get(15));

        Intent i1 = new Intent(this, Act2.class);
        i1.putExtra("Extra", result);
        String x = "Addition";
        i1.putExtra("which", x);
        startActivity(i1);
    }

    public void Multiply(View view) {
        setContentView(R.layout.activity_main);

        int[] result = new int[16];
        int[] result1 = new int[16];
        int[] result2 = new int[16];
        int[] result3 = new int[16];
        int[] result4 = new int[16];
        int[] result5 = new int[16];
        int[] result6 = new int[16];
        int[] result7 = new int[16];
        int[] result8 = new int[16];
        for(int settozero =0; settozero<16; settozero++){
            result[settozero]=0;
            result1[settozero]=0;
            result2[settozero]=0;
            result3[settozero]=0;
            result4[settozero]=0;
            result5[settozero]=0;
            result6[settozero]=0;
            result7[settozero]=0;
            result8[settozero]=0;

        }
        int j = 0;
        int k = 0;
        int i = 0;
        int stay =-4;

        for (k=0;k<4;k++){
             stay=+ stay+4;
        for(j=0;j<4;j++)
        {
            result1[i] = Integer.parseInt(Values.get(j+16));
            result5[i] = Integer.parseInt(Values.get(stay));
            result2[i] = Integer.parseInt(Values.get(j+4+16));
            result6[i] = Integer.parseInt(Values.get(stay+1));
            result3[i] = Integer.parseInt(Values.get(j+8+16));
            result7[i] = Integer.parseInt(Values.get(stay+2));
            result4[i] = Integer.parseInt(Values.get(j+12+16));
            result8[i] = Integer.parseInt(Values.get(stay+3));
            result[i] = (result1[i]*result5[i]) + (result2[i]*result6[i]) + (result3[i]*result7[i]) + (result4[i]*result8[i]);
            i++;
        }

        }
        Intent i1 = new Intent(this, Act2.class);
        i1.putExtra("Extra", result);
        String x = "Addition";
        i1.putExtra("which", x);
        startActivity(i1);
    }
}